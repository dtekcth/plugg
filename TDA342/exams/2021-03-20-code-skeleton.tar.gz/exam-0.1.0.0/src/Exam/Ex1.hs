{-# LANGUAGE UndecidableInstances #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE PolyKinds #-}
{-# LANGUAGE DataKinds #-}
{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE GADTs #-}
{-# LANGUAGE TypeFamilies #-}

module Exam.Ex1
where

import GHC.TypeLits

import Control.Applicative
import Prelude hiding (Monoid)

import Data.Proxy


-- Define a monoid based on a carrier t
data Monoid t = Empty | Elem t | Plus (Monoid t) (Monoid t)

-- Task 1.1: Define a graded monad only with static information below
data GMonad o m a = GMonad

-- Task 1.2: Define the following function and give its type signature
returnGMonad a = undefined
-- Task 1.2: Define the following function and give its type signature
bindGMonad m f = undefined
-- Task 1.2: Define the following function (you need to change the type signature)
runGMonad :: GMonad o m a -> m a
runGMonad m = undefined

-- 15pt: Proof that a graded monad is a monad
{-
Assumptions:

unGMonad . GMonad = id
GMonad . unGMonad = id


Law 1:
return x >>= f =?= f x

   return x >>= f
== (justification)
   ...
== (justification)
   .
   .
   .
== (justification)
  f x

Law 2:
m >>= return =?= m

   m >>= return
== (justification)
   ...
== (justification)
   .
   .
   .
== (justification)
   m

Law 3:
(m >>= f) >>= g =?= m >>= (\x -> f x >>= g)


   (m >>= f) >>= g
== (justification)
   ...
== (justification)
   .
   .
   .
== (justification)
   m >>= (\x -> f x >>= g)
-}
