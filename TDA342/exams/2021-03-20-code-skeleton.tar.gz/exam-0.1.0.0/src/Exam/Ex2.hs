{-# LANGUAGE DataKinds #-}
{-# LANGUAGE KindSignatures #-}
{-# LANGUAGE NoMonomorphismRestriction #-}
{-# LANGUAGE PolyKinds #-}
{-# LANGUAGE TypeFamilies #-}
{-# LANGUAGE TypeOperators #-}
{-# LANGUAGE UndecidableInstances #-}

module Exam.Ex2 where

import Prelude hiding ((>>), (>>=), return, Monoid)
import GHC.TypeLits
import Exam.Ex1
import Data.Proxy

----------------------------------------

return = returnGMonad
(>>=)  = bindGMonad
(>>)   = \x y -> x >>= const y

----------------------------------------

-- Task 2.1: Give the type-signature and definition of sWriteFile
-- (you need to change the type-signature below)
sWriteFile :: FilePath -> String -> GMonad o IO ()
sWriteFile file str = undefined

twoWrites  = sWriteFile "file1" "hello" >> sWriteFile "file2" "bye"
fourWrites = twoWrites >> twoWrites

-- Task 2.2: Provide the definition for Norm
type family Norm o :: Nat where
  Norm o = o

-- Task 2.3: Provide the type signature and definition of assertMaxWrites
assertMaxWrites p m = GMonad

okWrites = assertMaxWrites (Proxy :: Proxy 2) twoWrites
{- The next example should not type-check due to failed assertion:
   badWrites  = assertMaxWrites (Proxy :: Proxy 1) twoWrites
-}


-- Task 2.4: provide type-signature and implementation of the next two functions
-- (you need to change the type signature that is currently here)
sReadFile' :: String -> GMonad o IO String
sReadFile'  file     = undefined

sWriteFile' :: FilePath -> String -> GMonad o IO ()
sWriteFile' file str = undefined

-- Task 2.5: Provide the definition of Norm2

type family Norm2 o :: (Nat, Nat) where
  Norm2 o = o

-- Task 2.6: Provide the type-signature and implementation of the following fucntions
assertMaxReads'  p m = GMonad
assertMaxWrites' p m = GMonad

-- A computation that performs two writes and one read

twoWritesOneRead =
   sWriteFile' "file1" "hello" >> sReadFile' "file2" >>= (\s -> sWriteFile' "file3" s)

-- This examples should type-check correctly

good =  assertMaxWrites' (Proxy :: Proxy 2)
      $ assertMaxReads'  (Proxy :: Proxy 2)
      $ twoWritesOneRead

{- These examples should not type-check due to failed assertions

notgood1 = assertMaxWrites' (Proxy :: Proxy 2)
         $ assertMaxReads'  (Proxy :: Proxy 0)
         $ twoWritesOneRead

notgood2 = assertMaxWrites' (Proxy :: Proxy 1)
         $ assertMaxReads'  (Proxy :: Proxy 2)
         $ twoWritesOneRead
-}
